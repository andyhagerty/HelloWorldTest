﻿using Framework.Interfaces;

namespace Framework
{
    public class MyAPI : IMyAPI
    {
        #region Properties
        private string _outputLocation;
        #endregion

        #region Constructors
        public MyAPI(string output)
        {
            _outputLocation = output;
        }
        #endregion

        #region Execute
        public string Execute()
        {
            var call = new HelloWorldExecutionFactory();
            return call.Execute(_outputLocation.ToLower());
        }
        #endregion
    }
}
