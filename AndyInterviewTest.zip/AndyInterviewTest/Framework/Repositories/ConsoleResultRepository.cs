﻿using Domain.Constants;

namespace Framework.Repositories
{
    internal class ConsoleResultRepository : IConsoleResultRepository
    {
        public string Execute()
        {
            return Constants.HelloWorld;
        }
    }
}
