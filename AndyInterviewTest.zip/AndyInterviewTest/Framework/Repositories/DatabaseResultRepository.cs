﻿using System;
using Framework.Interfaces;

namespace Framework.Repositories
{
    class DatabaseResultRepository : IDatabaseResultRepository
    {
        public string Execute()
        {
            throw new NotImplementedException();
        }
    }
}
