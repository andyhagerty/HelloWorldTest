﻿
using Framework.Configuration;

namespace Framework.Repositories
{
    internal class DatabaseResult : DatabaseBase
    {
        internal void GetStuff()
        {
            ConfigurationManager.GetConnectionString();
        }
    }
}
