﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Framework.Configuration;

namespace Framework.Repositories
{
    abstract class FileBase
    {
        internal virtual string GetFileName()
        {
            return string.Format("NewFileName_{0}",Guid.NewGuid());
        }

        internal virtual string GetFileRootLocation()
        {
            return ConfigurationManager.GetLogPath();
        }
    }
}
