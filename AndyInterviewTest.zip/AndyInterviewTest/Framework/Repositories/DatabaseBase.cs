﻿using Framework.Configuration;

namespace Framework.Repositories
{
    abstract class DatabaseBase
    {
        protected virtual void CallSproc(string sprocName)
        {
            ConfigurationManager.GetConnectionString();
            //TODO - Add logic
        }
    }
}
