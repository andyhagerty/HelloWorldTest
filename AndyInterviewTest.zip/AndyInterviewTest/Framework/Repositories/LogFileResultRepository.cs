﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain.Constants;
using Framework.Interfaces;

namespace Framework.Repositories
{
    class LogFileResultRepository : FileBase
    {
        #region Execute
        public string Execute()
        {
            File.WriteAllText(BuildFilePath(), Constants.HelloWorld);
            return Constants.HelloWorld;
        }
        #endregion

        #region BuildFilePath
        public string BuildFilePath()
        {
            return string.Concat(GetFileRootLocation(), GetFileName());
        }
        #endregion

        #region GetFileName
        internal override string GetFileName()
        {
            return string.Format("AMuchCoolerFileName_{0}",Guid.NewGuid());
        }
        #endregion
    }
}
