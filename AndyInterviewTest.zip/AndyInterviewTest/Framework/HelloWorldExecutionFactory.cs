﻿using System;
using System.Collections.Generic;
using Domain.Constants;
using Framework.Service;

namespace Framework
{
    public class HelloWorldExecutionFactory
    {
        private readonly Dictionary<string, Func<string>> _handlers;

        #region Constructors
        public HelloWorldExecutionFactory()
        {
            _handlers = new Dictionary<string, Func<string>>
            {
                {Constants.ExecuteConsole, ConsoleResultHandler},
                {Constants.ExecuteLogFile, LogFileResultHandler},
                {Constants.ExecuteDatabase, DatabaseResultHandler}
            };
        }
        #endregion

        #region Execute
        public string Execute(string key)
        {
            string _result = null;
            if (_handlers.ContainsKey(key))
            {
                _result = _handlers[key].Invoke();
            }
            else
            {
                _result = _handlers[Constants.ExecuteConsole].Invoke();
            }
            return _result;
        }
        #endregion

        #region ConsoleResultHandler
        private string ConsoleResultHandler()
        {
            var _service = new ConsoleResultHandler();
            return _service.Execute();

        }
        #endregion

        #region LogFileResultHandler
        private string LogFileResultHandler()
        {
            var _service = new LogFileResultHandler();
            return _service.Execute();
        }
        #endregion

        #region DatabaseResultHandler
        private string DatabaseResultHandler()
        {
            //TODO
            return string.Empty;
        }
        #endregion
    }
}
