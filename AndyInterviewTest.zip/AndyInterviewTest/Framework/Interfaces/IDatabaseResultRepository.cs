﻿
namespace Framework.Interfaces
{
    interface IDatabaseResultRepository
    {
        string Execute();
    }
}
