﻿
namespace Framework.Repositories
{
    public interface IConsoleResultRepository
    {
        string Execute();

    }
}
