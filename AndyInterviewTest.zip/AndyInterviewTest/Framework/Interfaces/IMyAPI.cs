﻿
namespace Framework.Interfaces
{
    interface IMyAPI
    {
        string Execute();
    }
}
