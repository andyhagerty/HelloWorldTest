﻿
namespace Framework.Interfaces
{
    public interface ILogFileResultRepository
    {
        string Execute();
    }
}
