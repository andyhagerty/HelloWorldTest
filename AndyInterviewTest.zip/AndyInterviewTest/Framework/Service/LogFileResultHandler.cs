﻿using Framework.Repositories;

namespace Framework.Service
{
    class LogFileResultHandler
    {
        private readonly LogFileResultRepository _repository;
        #region Constructor
        public LogFileResultHandler()
        {
            _repository = new LogFileResultRepository();
        }
        #endregion

        #region Execute
        internal string Execute()
        {
            return _repository.Execute();
        }
        #endregion
    }
}
