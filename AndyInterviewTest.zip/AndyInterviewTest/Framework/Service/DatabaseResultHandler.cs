﻿using Framework.Repositories;

namespace Framework.Service
{
    class DatabaseResultHandler
    {
        private readonly DatabaseResultRepository _repository;
        #region Constructor
        public DatabaseResultHandler()
        {
            _repository = new DatabaseResultRepository();
        }
        #endregion

        #region Execute
        internal string Execute()
        {
            return _repository.Execute();
        }
        #endregion
    }
}
