﻿using Framework.Repositories;

namespace Framework
{
    internal class ConsoleResultHandler
    {
        private readonly ConsoleResultRepository _repository;
        #region Constructor
        public ConsoleResultHandler()
        {
            _repository = new ConsoleResultRepository();
        }
        #endregion

        #region Execute
        internal string Execute()
        {
            return _repository.Execute();
        }
        #endregion

    }
}
