﻿
namespace Framework.Configuration
{
    internal class ConfigurationManager
    {
        internal static string GetConnectionString()
        {
            return System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
        }

        internal static string GetLogPath()
        {
            return System.Configuration.ConfigurationManager.AppSettings["LogFilePath"];
        }
    }
}
