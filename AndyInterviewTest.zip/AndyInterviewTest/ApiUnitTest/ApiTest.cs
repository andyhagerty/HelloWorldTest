﻿using Framework;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ApiUnitTest
{
    [TestClass]
    public class ApiTest
    {
        private string _helloWorld = "Hello World!";
        [TestMethod]
        public void TestAPIForConsole()
        {
            var test = new MyAPI("Console");
            Assert.IsTrue(test.Execute() == _helloWorld);
        }

        [TestMethod]
        public void TestAPIForLog()
        {
            var test = new MyAPI("logfile");
            Assert.IsTrue(test.Execute() == _helloWorld);
        }
    }
}
