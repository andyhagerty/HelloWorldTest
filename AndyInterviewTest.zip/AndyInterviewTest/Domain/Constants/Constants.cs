﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Constants
{
    public class Constants
    {
        public const string ExecuteConsole = "console";
        public const string ExecuteDatabase = "database";
        public const string ExecuteLogFile = "logfile";
        public const string HelloWorld = "Hello World!";
    }
}
