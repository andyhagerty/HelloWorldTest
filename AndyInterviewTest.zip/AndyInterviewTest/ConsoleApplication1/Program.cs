﻿using System;
using Framework;

namespace ConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            var test = new MyAPI("Console");
            Console.WriteLine(test.Execute());
        }
    }
}
